/* SPDX-License-Identifier: LGPL-3.0-or-later */

/*
 * This file contains Linux-SGX-specific functions related to the PAL.
 */

#ifndef __LINUX_SGX_X86_64_PAL_HOST_ARCH_H__
#define __LINUX_SGX_X86_64_PAL_HOST_ARCH_H__

#endif /* __LINUX_SGX_X86_64_PAL_HOST_ARCH_H__ */
