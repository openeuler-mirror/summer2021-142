/* SPDX-License-Identifier: LGPL-3.0-or-later */

/*
 * This file contains Skeleton-specific functions related to the PAL.
 */
