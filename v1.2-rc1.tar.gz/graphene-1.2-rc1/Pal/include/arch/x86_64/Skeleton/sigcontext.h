/* SPDX-License-Identifier: LGPL-3.0-or-later */

#ifndef _SKELETON_SIGCONTEXT_H
#define _SKELETON_SIGCONTEXT_H

#endif /* _SKELETON_SIGCONTEXT_H */
