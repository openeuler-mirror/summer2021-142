/* SPDX-License-Identifier: LGPL-3.0-or-later */

/*
 * Skeleton uses Linux's ucontext.h (for now)
 */

#ifndef _SKELETON_UCONTEXT_H
#define _SKELETON_UCONTEXT_H

#include "Linux/ucontext.h"

#endif /* _SKELETON_UCONTEXT_H */
