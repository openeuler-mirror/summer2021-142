#include <stdio.h>

int main(int argc, const char** argv, const char** envp) {
    return 113;
}
