/* SPDX-License-Identifier: LGPL-3.0-or-later */

#ifndef _SHIM_VDSO_ARCH_H_
#define _SHIM_VDSO_ARCH_H_

#define LINUX_VDSO_FILENAME "linux-vdso.so.1"

#endif /* _SHIM_VDSO_ARCH_H_ */
