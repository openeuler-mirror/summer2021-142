LibOS documentation
===================

.. note::

   This file is more like a |~| stub, not yet a |~| real documentation.

There is a |~| random function:

.. doxygenfunction:: object_wait_with_retry
   :project: libos
